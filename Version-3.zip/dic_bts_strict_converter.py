"""
DIC应变 → BTS应力：严格对标文献完整版本

完整实现文献式1-2, 1-3, 1-4, 1-5, 1-6
包含所有绘图函数和数据处理
"""

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pathlib import Path
import warnings

plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False
warnings.filterwarnings('ignore')


class GriffithCriterion:
    """Griffith破坏准则（文献式1-4）"""
    
    @staticmethod
    def calculate(sigma_1, sigma_3):
        condition = 3 * sigma_1 + sigma_3
        
        if condition >= 0:
            sigma_G = sigma_1
            criterion_type = "第一分支（拉应力主导）"
        else:
            denominator = 8 * (sigma_1 + sigma_3)
            if abs(denominator) < 1e-10:
                sigma_G = sigma_1
            else:
                sigma_G = (sigma_1 - sigma_3)**2 / denominator
            criterion_type = "第二分支（压应力主导）"
        
        return {
            'sigma_G': sigma_G,
            'criterion_type': criterion_type,
            'condition': condition,
        }


class HondrosTheory:
    """Hondros弦形载荷理论（文献式1-6）"""
    
    def __init__(self, R, t, alpha_deg=15):
        self.R = R
        self.t = t
        self.alpha = np.deg2rad(alpha_deg)
    
    def calculate_stress(self, r, p):
        ratio = r / self.R
        
        if ratio > 1.0:
            return {'sigma_r': 0, 'sigma_theta': 0}
        
        alpha = self.alpha
        numerator_1 = (1 - ratio**2) * np.sin(2*alpha)
        denominator_1 = 1 - 2*np.cos(2*alpha) * (ratio**2 + ratio**4)
        
        if abs(denominator_1) < 1e-10:
            term_1 = 0
        else:
            term_1 = numerator_1 / denominator_1
        
        tan_alpha = np.tan(alpha)
        numerator_2 = (1 + ratio**2) * tan_alpha
        denominator_2 = 1 - ratio**2
        
        if abs(denominator_2) < 1e-10:
            arctan_arg = 0
        else:
            arctan_arg = numerator_2 / denominator_2
        
        term_2 = np.arctan(arctan_arg) * tan_alpha
        const = p / (np.pi * self.R * self.t * alpha)
        
        sigma_r = -const * term_1
        sigma_theta = const * (term_1 - term_2)
        
        return {'sigma_r': sigma_r, 'sigma_theta': sigma_theta}


class KirschStressCalculator:
    """Kirsch应力计算器（文献式1-2）"""
    
    def __init__(self, D, t):
        self.D = D
        self.t = t
        self.R = D / 2
        self.hondros = HondrosTheory(D/2, t)
    
    def get_load_point_angles(self, x, y):
        eps = 1e-6
        x1, y1 = 0, self.R
        rho1 = np.sqrt((x - x1)**2 + (y - y1)**2) + eps
        theta1 = np.arctan2(y - y1, x - x1)
        
        x2, y2 = 0, -self.R
        rho2 = np.sqrt((x - x2)**2 + (y - y2)**2) + eps
        theta2 = np.arctan2(y - y2, x - x2)
        
        return theta1, rho1, theta2, rho2
    
    def calculate_stress_kirsch(self, x, y, P):
        """Kirsch公式（式1-2）"""
        
        theta1, rho1, theta2, rho2 = self.get_load_point_angles(x, y)
        r = np.sqrt(x**2 + y**2)
        theta = np.arctan2(y, x)
        
        const = 2 * P / (np.pi * self.t)
        
        sigma_r = const * (
            np.cos(theta1) * np.sin(theta1)**2 / rho1 +
            np.cos(theta2) * np.sin(theta2)**2 / rho2
        ) - const * self.D / 2
        
        sigma_theta = const * (
            np.cos(theta1)**3 / rho1 +
            np.cos(theta2)**3 / rho2
        ) - const * self.D / 2
        
        tau_r_theta = const * (
            np.cos(theta2)**3 * np.sin(theta2) / rho2 -
            np.cos(theta1)**3 * np.sin(theta1) / rho1
        )
        
        cos_th = np.cos(theta)
        sin_th = np.sin(theta)
        
        sigma_x = (sigma_r * cos_th**2 + sigma_theta * sin_th**2 - 
                   2 * tau_r_theta * sin_th * cos_th)
        sigma_y = (sigma_r * sin_th**2 + sigma_theta * cos_th**2 + 
                   2 * tau_r_theta * sin_th * cos_th)
        tau_xy = ((sigma_r - sigma_theta) * sin_th * cos_th + 
                  tau_r_theta * (cos_th**2 - sin_th**2))
        
        return sigma_x, sigma_y, tau_xy
    
    def calculate_stress_hondros(self, x, y, P):
        """Hondros理论（式1-6）"""
        
        r = np.sqrt(x**2 + y**2)
        theta = np.arctan2(y, x)
        
        p = P / (2 * self.R * np.sin(self.hondros.alpha))
        stress = self.hondros.calculate_stress(r, p)
        sigma_r = stress['sigma_r']
        sigma_theta = stress['sigma_theta']
        tau_r_theta = 0
        
        cos_th = np.cos(theta)
        sin_th = np.sin(theta)
        
        sigma_x = (sigma_r * cos_th**2 + sigma_theta * sin_th**2 - 
                   2 * tau_r_theta * sin_th * cos_th)
        sigma_y = (sigma_r * sin_th**2 + sigma_theta * cos_th**2 + 
                   2 * tau_r_theta * sin_th * cos_th)
        tau_xy = ((sigma_r - sigma_theta) * sin_th * cos_th + 
                  tau_r_theta * (cos_th**2 - sin_th**2))
        
        return sigma_x, sigma_y, tau_xy


class DICBTSStrictConverter:
    """DIC-BTS严格对标文献转换器"""
    
    def __init__(self, E, nu, D, t):
        self.E = E
        self.nu = nu
        self.D = D
        self.t = t
        self.G = E / (2 * (1 + nu))
        self.factor = E / (1 - nu**2)
        self.kirsch = KirschStressCalculator(D, t)
        self.griffith = GriffithCriterion()
        
        print("\n" + "="*70)
        print("  DIC-BTS严格对标文献系统")
        print("  实现式1-2, 1-3, 1-4, 1-5, 1-6")
        print("="*70)
        print(f"\n✅ 转换器初始化")
        print(f"\n【材料参数】")
        print(f"  杨氏模量 E = {E/1e9:.1f} GPa")
        print(f"  泊松比 ν = {nu}")
        print(f"\n【样本几何参数】")
        print(f"  直径 D = {D:.1f} mm")
        print(f"  厚度 t = {t:.1f} mm")
        print(f"\n" + "-"*70 + "\n")
    
    def calculate_stress_from_strain(self, exx, eyy, exy):
        """从应变计算应力（本构关系）"""
        sigma_xx = self.factor * (exx + self.nu * eyy)
        sigma_yy = self.factor * (eyy + self.nu * exx)
        tau_xy = self.G * exy
        return sigma_xx, sigma_yy, tau_xy
    
    def process_dic_excel_strict(self, excel_file, output_dir, P_assumed=None):
        """处理Excel文件"""
        
        print(f"📊 处理文件: {Path(excel_file).name}")
        
        # 读取Excel
        df = pd.read_excel(excel_file)
        print(f"   原始数据形状: {df.shape}")
        
        # ��单的列名处理：去掉括号
        column_mapping = {}
        for col in df.columns:
            col_clean = col.split('(')[0].strip().lower()
            if col_clean in ['x', 'y', 'u', 'v', 'exx', 'eyy', 'exy']:
                column_mapping[col] = col_clean
        
        # 检查是否找到了所有必要的列
        required_cols = ['x', 'y', 'exx', 'eyy', 'exy']
        found_cols = set(column_mapping.values())
        
        if not all(rc in found_cols for rc in required_cols):
            print(f"   ❌ 缺少必要的列！")
            raise ValueError("缺少必要的列")
        
        # 重命名列
        df = df.rename(columns=column_mapping)
        df = df[required_cols]
        
        print(f"   数据点数: {len(df)}")
        
        # ========== 【改进：检查数据是否全是0】 ==========
        data_std = df[['exx', 'eyy', 'exy']].std().sum()
        
        if P_assumed is None:
            if data_std < 1e-10:  # 数据全是0或几乎全是0
                print(f"   ⚠️ 应变数据全是0，使用默认P = 5000 N")
                P_assumed = 5000
            else:
                # 从圆心估计P（原始逻辑）
                center_distance = 5.0
                center_points = df[
                    (df['x'].abs() < center_distance) & 
                    (df['y'].abs() < center_distance)
                ]
                
                if len(center_points) > 1:
                    avg_exx = center_points['exx'].mean()
                    avg_eyy = center_points['eyy'].mean()
                    avg_exy = center_points['exy'].mean()
                    
                    sigma_xx_c, sigma_yy_c, _ = self.calculate_stress_from_strain(
                        avg_exx, avg_eyy, avg_exy
                    )
                    
                    if abs(sigma_yy_c) > 1e-10:
                        P_assumed = sigma_yy_c * np.pi * self.D * self.t / 6
                    else:
                        P_assumed = 5000
                else:
                    P_assumed = 5000
                
                print(f"   推断P = {P_assumed:.0f} N")
        
        # ========== 【继续处理数据】 ==========
        results = []
        
        for idx, row in df.iterrows():
            try:
                x = row['x']
                y = row['y']
                exx = row['exx']
                eyy = row['eyy']
                exy = row['exy']
                
                # 方法1：本构关系
                sigma_xx_const, sigma_yy_const, tau_xy_const = \
                    self.calculate_stress_from_strain(exx, eyy, exy)
                
                # 方法2：Kirsch（式1-2）
                sigma_xx_k, sigma_yy_k, tau_xy_k = \
                    self.kirsch.calculate_stress_kirsch(x, y, P_assumed)
                
                # 方法3：Hondros（式1-6）
                sigma_xx_h, sigma_yy_h, tau_xy_h = \
                    self.kirsch.calculate_stress_hondros(x, y, P_assumed)
                
                # von Mises（添加检查，避免NaN）
                s_mises_const = np.sqrt(max(0, sigma_xx_const**2 + sigma_yy_const**2 - 
                                       sigma_xx_const*sigma_yy_const + 3*tau_xy_const**2))
                s_mises_k = np.sqrt(max(0, sigma_xx_k**2 + sigma_yy_k**2 - 
                                   sigma_xx_k*sigma_yy_k + 3*tau_xy_k**2))
                s_mises_h = np.sqrt(max(0, sigma_xx_h**2 + sigma_yy_h**2 - 
                                   sigma_xx_h*sigma_yy_h + 3*tau_xy_h**2))
                
                # Griffith破坏准则
                sigma_1 = max(sigma_xx_k, sigma_yy_k)
                sigma_3 = min(sigma_xx_k, sigma_yy_k)
                griffith = self.griffith.calculate(sigma_1, sigma_3)
                
                # 抗拉强度
                sigma_t_const = sigma_yy_const / 3
                sigma_t_k = sigma_yy_k / 3
                sigma_t_h = sigma_yy_h / 3
                
                results.append({
                    'x': x, 'y': y,
                    'exx': exx, 'eyy': eyy, 'exy': exy,
                    'sigma_xx_const': sigma_xx_const,
                    'sigma_yy_const': sigma_yy_const,
                    'tau_xy_const': tau_xy_const,
                    'sigma_mises_const': s_mises_const,
                    'sigma_t_const': sigma_t_const,
                    'sigma_xx_kirsch': sigma_xx_k,
                    'sigma_yy_kirsch': sigma_yy_k,
                    'tau_xy_kirsch': tau_xy_k,
                    'sigma_mises_kirsch': s_mises_k,
                    'sigma_t_kirsch': sigma_t_k,
                    'sigma_xx_hondros': sigma_xx_h,
                    'sigma_yy_hondros': sigma_yy_h,
                    'tau_xy_hondros': tau_xy_h,
                    'sigma_mises_hondros': s_mises_h,
                    'sigma_t_hondros': sigma_t_h,
                    'sigma_1': sigma_1,
                    'sigma_3': sigma_3,
                    'sigma_G': griffith['sigma_G'],
                    'griffith_condition': griffith['condition'],
                    'griffith_criterion_type': griffith['criterion_type'],
                })
            
            except Exception as e:
                if idx < 3:
                    print(f"   ⚠️ 第{idx}行: {e}")
                continue
        
        results_df = pd.DataFrame(results)
        
        # 保存结果
        Path(output_dir).mkdir(parents=True, exist_ok=True)
        output_file = Path(output_dir) / f"{Path(excel_file).stem}_strict.csv"
        results_df.to_csv(output_file, index=False, encoding='utf-8-sig')
        
        print(f"   ✓ 已保存: {output_file.name}\n")
        
        return results_df
    
    def plot_stress_comparison_three_methods(self, results_df, output_dir):
        """三方法对比图"""
        if len(results_df) < 10:
            return
        
        try:
            fig, axes = plt.subplots(2, 3, figsize=(18, 10))
            fig.suptitle('三种应力计算方法对比', fontsize=14, fontweight='bold')
            
            x, y = results_df['x'].values, results_df['y'].values
            
            axes[0,0].scatter(x, y, c=results_df['sigma_xx_const'], cmap='RdBu_r', s=10, alpha=0.6)
            axes[0,0].set_title('σxx (本构关系)', fontsize=11)
            axes[0,0].set_aspect('equal')
            
            axes[0,1].scatter(x, y, c=results_df['sigma_xx_kirsch'], cmap='RdBu_r', s=10, alpha=0.6)
            axes[0,1].set_title('σxx (Kirsch 式1-2)', fontsize=11)
            axes[0,1].set_aspect('equal')
            
            axes[0,2].scatter(x, y, c=results_df['sigma_xx_hondros'], cmap='RdBu_r', s=10, alpha=0.6)
            axes[0,2].set_title('σxx (Hondros 式1-6)', fontsize=11)
            axes[0,2].set_aspect('equal')
            
            axes[1,0].scatter(x, y, c=results_df['sigma_yy_const'], cmap='RdBu_r', s=10, alpha=0.6)
            axes[1,0].set_title('σyy (本构关系)', fontsize=11)
            axes[1,0].set_aspect('equal')
            
            axes[1,1].scatter(x, y, c=results_df['sigma_yy_kirsch'], cmap='RdBu_r', s=10, alpha=0.6)
            axes[1,1].set_title('σyy (Kirsch 式1-2)', fontsize=11)
            axes[1,1].set_aspect('equal')
            
            axes[1,2].scatter(x, y, c=results_df['sigma_yy_hondros'], cmap='RdBu_r', s=10, alpha=0.6)
            axes[1,2].set_title('σyy (Hondros 式1-6)', fontsize=11)
            axes[1,2].set_aspect('equal')
            
            plt.tight_layout()
            plt.savefig(Path(output_dir) / 'comparison_three_methods.png', dpi=100, bbox_inches='tight')
            plt.close()
            print(f"✅ 三方法对比图已保存")
        except Exception as e:
            print(f"⚠️ 绘图出错: {e}")
    
    def plot_griffith_criterion_analysis(self, results_df, output_dir):
        """Griffith准则分析"""
        if len(results_df) < 10:
            return
        
        try:
            fig, axes = plt.subplots(1, 2, figsize=(14, 6))
            fig.suptitle('Griffith破坏准则分析（式1-4）', fontsize=13)
            
            x, y = results_df['x'].values, results_df['y'].values
            
            axes[0].scatter(x, y, c=results_df['griffith_condition'], cmap='RdBu_r', s=10, alpha=0.6)
            axes[0].set_title('3σ₁ + σ₃ 的分布')
            axes[0].set_aspect('equal')
            
            axes[1].scatter(x, y, c=results_df['sigma_G'], cmap='jet', s=10, alpha=0.6)
            axes[1].set_title('破坏应力 σG 的分布')
            axes[1].set_aspect('equal')
            
            plt.tight_layout()
            plt.savefig(Path(output_dir) / 'griffith_criterion_analysis.png', dpi=100, bbox_inches='tight')
            plt.close()
            print(f"✅ Griffith准则分析图已保存")
        except Exception as e:
            print(f"⚠️ 绘图出错: {e}")
    
    def plot_stress_along_diameter(self, results_df, output_dir):
        """沿直径的应力分布"""
        try:
            fig, axes = plt.subplots(1, 2, figsize=(14, 6))
            fig.suptitle('沿圆形直径的应力分布', fontsize=13)
            
            # 竖直直径
            v_points = results_df[results_df['x'].abs() < 2.0].sort_values('y')
            if len(v_points) > 2:
                axes[0].plot(v_points['y'], v_points['sigma_yy_const'], 'o-', label='本构', linewidth=2, markersize=4)
                axes[0].plot(v_points['y'], v_points['sigma_yy_kirsch'], 's--', label='Kirsch', linewidth=2, markersize=4)
                axes[0].plot(v_points['y'], v_points['sigma_yy_hondros'], '^:', label='Hondros', linewidth=2, markersize=4)
                axes[0].set_title('竖直直径(Y轴)的σyy')
                axes[0].set_xlabel('Y坐标 (mm)')
                axes[0].set_ylabel('σyy (MPa)')
                axes[0].legend()
                axes[0].grid(True, alpha=0.3)
            
            # 水平直径
            h_points = results_df[results_df['y'].abs() < 2.0].sort_values('x')
            if len(h_points) > 2:
                axes[1].plot(h_points['x'], h_points['sigma_xx_const'], 'o-', label='本构', linewidth=2, markersize=4)
                axes[1].plot(h_points['x'], h_points['sigma_xx_kirsch'], 's--', label='Kirsch', linewidth=2, markersize=4)
                axes[1].plot(h_points['x'], h_points['sigma_xx_hondros'], '^:', label='Hondros', linewidth=2, markersize=4)
                axes[1].set_title('水平直径(X轴)的σxx')
                axes[1].set_xlabel('X坐标 (mm)')
                axes[1].set_ylabel('σxx (MPa)')
                axes[1].legend()
                axes[1].grid(True, alpha=0.3)
            
            plt.tight_layout()
            plt.savefig(Path(output_dir) / 'stress_along_diameter.png', dpi=100, bbox_inches='tight')
            plt.close()
            print(f"✅ 直径应力分布图已保存")
        except Exception as e:
            print(f"⚠️ 绘图出错: {e}")
    
    def generate_strict_report(self, results_df, excel_file, output_dir):
        """生成详细报告"""
        report_file = Path(output_dir) / f"{Path(excel_file).stem}_strict_report.txt"
        
        try:
            with open(report_file, 'w', encoding='utf-8') as f:
                f.write("="*70 + "\n")
                f.write(f"DIC-BTS严格对标文献分析报告\n")
                f.write(f"文件: {Path(excel_file).name}\n")
                f.write("="*70 + "\n\n")
                
                f.write("【1】使用的文献公式\n")
                f.write("-"*70 + "\n\n")
                f.write("式1-2：Kirsch圆盘完全解（极坐标应力）\n")
                f.write("式1-3：圆心处应力简化\n")
                f.write("式1-4：Griffith破坏准则\n")
                f.write("式1-5：抗拉强度σt = σy/3\n")
                f.write("式1-6：Hondros弦形载荷理论\n\n")
                
                f.write("【2】统计结果\n")
                f.write("-"*70 + "\n\n")
                f.write(f"数据点数: {len(results_df)}\n")
                f.write(f"σxx范围: [{results_df['sigma_xx_kirsch'].min():.6f}, {results_df['sigma_xx_kirsch'].max():.6f}] MPa\n")
                f.write(f"σyy范围: [{results_df['sigma_yy_kirsch'].min():.6f}, {results_df['sigma_yy_kirsch'].max():.6f}] MPa\n")
                
                f.write(f"\n抗拉强度σt:\n")
                f.write(f"  本构关系: {results_df['sigma_t_const'].mean():.6f} MPa\n")
                f.write(f"  Kirsch:   {results_df['sigma_t_kirsch'].mean():.6f} MPa\n")
                f.write(f"  Hondros:  {results_df['sigma_t_hondros'].mean():.6f} MPa\n")
                
                branch1 = (results_df['griffith_condition'] >= 0).sum()
                branch2 = (results_df['griffith_condition'] < 0).sum()
                f.write(f"\nGriffith准则:\n")
                f.write(f"  第一分支: {branch1} 个点 ({100*branch1/len(results_df):.1f}%)\n")
                f.write(f"  第二分支: {branch2} 个点 ({100*branch2/len(results_df):.1f}%)\n")
            
            print(f"✅ 报告已保存")
        except Exception as e:
            print(f"⚠️ 报告生成出错: {e}")