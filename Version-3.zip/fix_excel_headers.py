"""
批量修改Excel列名，去掉(mm)
如果你的Excel列名是 'x(mm)' 等格式，运行这个脚本修复
"""

import pandas as pd
from pathlib import Path

input_dir = './strain_data'
input_path = Path(input_dir)
excel_files = sorted(input_path.glob('CT_*.xlsx'))

print(f"找到 {len(excel_files)} 个文件\n")

for excel_file in excel_files:
    print(f"处理: {excel_file.name}")
    
    # 读取
    df = pd.read_excel(excel_file)
    
    # 修改列名：去掉括号内的内容
    new_columns = {}
    for col in df.columns:
        new_col = col.split('(')[0].strip()  # 去掉(mm)部分
        new_columns[col] = new_col
    
    df = df.rename(columns=new_columns)
    
    # 保存（覆盖原文件）
    df.to_excel(excel_file, index=False)
    print(f"  ✓ 已修改并保存\n")

print("✅ 所有文件已修改完成！")