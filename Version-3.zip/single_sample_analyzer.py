"""
针对少量Excel文件的DIC-BTS分析工具

特别优化：
- 支持任意数量的文件
- 详细的单样本分析
- 完整的可视化和报告
"""

from pathlib import Path
from dic_bts_strict_converter import DICBTSStrictConverter
import pandas as pd
import numpy as np


def analyze_samples():
    """专门针对少量样本的分析"""
    
    print("\n" + "="*70)
    print("  DIC-BTS严格对标文献系统 - 样本分析版本")
    print("="*70 + "\n")
    
    # ========== 【参数配置】 ==========
    print("【配置阶段】")
    print("-"*70)
    
    # 花岗岩参数
    E = 5e10      # 50 GPa
    nu = 0.25     # 泊松比
    D = 50.0      # 直径 mm
    t = 25.0      # 厚度 mm
    P_force = 5000  # 破坏载荷 N（如果数据全是0，使用这个值）
    
    print(f"✓ 材料：花岗岩")
    print(f"✓ E = {E/1e9:.0f} GPa, ν = {nu}")
    print(f"✓ 样本：D = {D:.1f} mm, t = {t:.1f} mm")
    print(f"✓ 破坏载荷：P = {P_force:.0f} N\n")
    
    # 文件夹路径
    input_dir = './strain_data'
    output_dir = './DIC_BTS_strict_output'
    
    # 检查输入文件夹是否存在
    input_path = Path(input_dir)
    if not input_path.exists():
        print(f"❌ 错误：输入文件夹 {input_dir} 不存在")
        print(f"   请创建 {input_dir} 文件夹，并将Excel文件放入\n")
        return
    
    # 获取所有Excel文件
    excel_files = sorted(input_path.glob('CT_*.xlsx'))
    
    if len(excel_files) == 0:
        print(f"❌ 错误：在 {input_dir} 中找不到 CT_*.xlsx 文件")
        print(f"   请检查：")
        print(f"   1. 文件名是否以 CT_ 开头")
        print(f"   2. 扩展名是否为 .xlsx")
        print(f"   3. 文件夹路径是否正确\n")
        return
    
    total_files = len(excel_files)
    print(f"✓ 找到 {total_files} 个Excel文件")
    print(f"  文件列表：")
    for i, f in enumerate(excel_files, 1):
        print(f"    {i}. {f.name}")
    print()
    
    # ========== 【创建转换器】 ==========
    print("【初始化转换器】")
    print("-"*70)
    
    converter = DICBTSStrictConverter(E, nu, D, t)
    
    # ========== 【逐文件处理】 ==========
    print("\n【处理每个文件】")
    print("-"*70 + "\n")
    
    all_results = []
    summary_list = []
    
    for file_idx, excel_file in enumerate(excel_files, 1):
        print(f"\n{file_idx}. 处理文件：{excel_file.name}")
        print("   " + "-"*60)
        
        try:
            # 处理单个文件（直接指定P值）
            results_df = converter.process_dic_excel_strict(
                str(excel_file), output_dir, P_assumed=P_force
            )
            
            all_results.append(results_df)
            
            # ========== 单样本统计 ==========
            print(f"\n   【{excel_file.name} 的统计结果】")
            
            # 应力统计
            print(f"   应力分量统计：")
            print(f"     σxx: [{results_df['sigma_xx_kirsch'].min():.3f}, "
                  f"{results_df['sigma_xx_kirsch'].max():.3f}] MPa")
            print(f"     σyy: [{results_df['sigma_yy_kirsch'].min():.3f}, "
                  f"{results_df['sigma_yy_kirsch'].max():.3f}] MPa")
            
            # 抗拉强度
            sigma_t_const = results_df['sigma_t_const'].mean()
            sigma_t_kirsch = results_df['sigma_t_kirsch'].mean()
            sigma_t_hondros = results_df['sigma_t_hondros'].mean()
            
            print(f"\n   抗拉强度σt：")
            print(f"     本构关系: {sigma_t_const:.3f} MPa")
            print(f"     Kirsch:   {sigma_t_kirsch:.3f} MPa")
            print(f"     Hondros:  {sigma_t_hondros:.3f} MPa")
            
            # Griffith准则
            branch1_count = (results_df['griffith_condition'] >= 0).sum()
            branch2_count = (results_df['griffith_condition'] < 0).sum()
            total_points = len(results_df)
            
            print(f"\n   Griffith破坏准则分布：")
            print(f"     第一分支（拉应力主导）: {branch1_count:6d}个 ({100*branch1_count/total_points:5.1f}%)")
            print(f"     第二分支（压应力主导）: {branch2_count:6d}个 ({100*branch2_count/total_points:5.1f}%)")
            
            # 方法一致性
            diff_xx = (results_df['sigma_xx_const'] - results_df['sigma_xx_kirsch']).abs().mean()
            diff_yy = (results_df['sigma_yy_const'] - results_df['sigma_yy_kirsch']).abs().mean()
            
            print(f"\n   本构关系 vs Kirsch的差异：")
            print(f"     σxx: {diff_xx:.4f} MPa")
            print(f"     σyy: {diff_yy:.4f} MPa")
            
            # 保存汇总
            summary_list.append({
                'file_name': excel_file.name,
                'num_points': len(results_df),
                'sigma_t_const': sigma_t_const,
                'sigma_t_kirsch': sigma_t_kirsch,
                'sigma_t_hondros': sigma_t_hondros,
                'griffith_branch1': branch1_count,
                'griffith_branch1_pct': 100*branch1_count/total_points,
                'griffith_branch2': branch2_count,
                'griffith_branch2_pct': 100*branch2_count/total_points,
                'diff_sigma_xx': diff_xx,
                'diff_sigma_yy': diff_yy,
            })
            
            # 绘制对比图
            print(f"\n   正在生成可视化图表...")
            converter.plot_stress_comparison_three_methods(results_df, output_dir)
            converter.plot_griffith_criterion_analysis(results_df, output_dir)
            converter.plot_stress_along_diameter(results_df, output_dir)
            print(f"   ✓ 图表生成完成")
            
            # 生成报告
            print(f"\n   正在生成详细报告...")
            converter.generate_strict_report(results_df, excel_file, output_dir)
            print(f"   ✓ 报告生成完成")
            
        except Exception as e:
            print(f"   ❌ 处理出错: {e}")
            import traceback
            traceback.print_exc()
            continue
    
    # ========== 【汇总统计】 ==========
    print("\n" + "="*70)
    print("【汇总统计】")
    print("="*70)
    
    if len(summary_list) > 0:
        summary_df = pd.DataFrame(summary_list)
        
        # 保存汇总表
        summary_file = Path(output_dir) / 'DIC_BTS_summary.csv'
        summary_df.to_csv(summary_file, index=False, encoding='utf-8-sig')
        print(f"\n✓ 汇总表已保存: {summary_file}")
        
        # 显示汇总表
        print(f"\n【汇总表】")
        print("-"*70)
        print(summary_df.to_string(index=False))
        
        # 全局统计
        print(f"\n【全局统计】")
        print("-"*70)
        
        print(f"\n抗拉强度σt统计：")
        print(f"  本构关系:")
        print(f"    平均值: {summary_df['sigma_t_const'].mean():.3f} MPa")
        print(f"    范围: [{summary_df['sigma_t_const'].min():.3f}, "
              f"{summary_df['sigma_t_const'].max():.3f}] MPa")
        
        print(f"  Kirsch理论:")
        print(f"    平均值: {summary_df['sigma_t_kirsch'].mean():.3f} MPa")
        print(f"    范围: [{summary_df['sigma_t_kirsch'].min():.3f}, "
              f"{summary_df['sigma_t_kirsch'].max():.3f}] MPa")
        
        print(f"  Hondros理论:")
        print(f"    平均值: {summary_df['sigma_t_hondros'].mean():.3f} MPa")
        print(f"    范围: [{summary_df['sigma_t_hondros'].min():.3f}, "
              f"{summary_df['sigma_t_hondros'].max():.3f}] MPa")
        
        print(f"\nGriffith准则分布统计：")
        total_branch1 = summary_df['griffith_branch1'].sum()
        total_branch2 = summary_df['griffith_branch2'].sum()
        total_all = total_branch1 + total_branch2
        
        print(f"  第一分支：{total_branch1:6d}个点 ({100*total_branch1/total_all:5.1f}%)")
        print(f"  第二分支：{total_branch2:6d}个点 ({100*total_branch2/total_all:5.1f}%)")
        
        print(f"\n三种方法的平均差异：")
        print(f"  σxx差异: {summary_df['diff_sigma_xx'].mean():.4f} MPa")
        print(f"  σyy差异: {summary_df['diff_sigma_yy'].mean():.4f} MPa")
        
        # 判断数据质量
        avg_diff_xx = summary_df['diff_sigma_xx'].mean()
        avg_diff_yy = summary_df['diff_sigma_yy'].mean()
        
        if avg_diff_xx < 0.1 and avg_diff_yy < 0.1:
            quality = "✓ 优良"
        elif avg_diff_xx < 0.2 and avg_diff_yy < 0.2:
            quality = "✓ 良好"
        else:
            quality = "⚠ 一般"
        
        print(f"\n数据质量评估: {quality}")
        if quality == "✓ 优良":
            print("  • 三种方法结果高度一致")
            print("  • 材料参���(E, ν)准确")
            print("  • DIC测量质量优良")
        elif quality == "✓ 良好":
            print("  • 三种方法结果基本一致")
            print("  • 材料参数和DIC测量质量都可以")
        else:
            print("  ⚠ 方法之间有较大差异")
            print("  • 建议检查材料参数的准确性")
            print("  • 或检查DIC数据的质量")
    
    print("\n" + "="*70)
    print("✅ 分析完成！")
    print("="*70)
    print(f"\n📁 所有结果已保存在: {output_dir}")
    print(f"   • *_strict.csv - 每个样本的详细数据")
    print(f"   • *_strict_report.txt - 每个样本的详细报告")
    print(f"   • comparison_three_methods.png - 三方法对比图")
    print(f"   • griffith_criterion_analysis.png - Griffith准则分析")
    print(f"   • stress_along_diameter.png - 直径应力分布")
    print(f"   • DIC_BTS_summary.csv - 汇总统计表")
    print()


if __name__ == "__main__":
    try:
        analyze_samples()
    except Exception as e:
        print(f"\n❌ 程序执行出错: {e}")
        import traceback
        traceback.print_exc()